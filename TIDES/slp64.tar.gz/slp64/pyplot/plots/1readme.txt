Subdirectory /slp64\pyplot/plots

This is where the output of the plot programs are placed.  Users should 
move to another location or delete files as they accumulate to make it easier
to find your desired plots.
