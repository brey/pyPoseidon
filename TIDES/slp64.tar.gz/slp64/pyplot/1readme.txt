/slp64/pyplot directory:

Plot programs

Uses Matplotlib for plotting routines and numpy for working with variable arrays

Programs:
hplot.py: plot hourly tide data or hourly residuals
dplot.py and mplot.py: daily and monthly, respectively, plot programs
d2diff.py and m2diff.py: 1) two series (de-meaned) on one plot, 2) difference plot
scat.py: scatter diagram plot of tide gauge and tide staff reading pairs

directories:
src\: Fortran code and executables for programs to convert from SLP64 processing 
     format to CSV, which is used internally by the various plot programs.

     compiled as gfortran -static file.for -o file.exe

plots\: holds output plots from python plot programs; delete these files if desired


Notes on Python:

Copyright (c) 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011,
2012, 2013 Python Software Foundation.  All rights reserved.

Copyright (c) 2000 BeOpen.com.
All rights reserved.

Copyright (c) 1995-2001 Corporation for National Research Initiatives.
All rights reserved.

Copyright (c) 1991-1995 Stichting Mathematisch Centrum.
All rights reserved.


License information
-------------------

See the file "LICENSE" for information on the history of this
software, terms & conditions for usage, and a DISCLAIMER OF ALL
WARRANTIES.

This Python distribution contains no GNU General Public Licensed
(GPLed) code so it may be used in proprietary projects just like prior
Python distributions.  There are interfaces to some GNU code but these
are entirely optional.

All trademarks referenced herein are property of their respective
holders.


What is Python anyway?
----------------------

Python is an interpreted, interactive object-oriented programming
language suitable (amongst other uses) for distributed application
development, scripting, numeric computing and system testing.  Python
is often compared to Tcl, Perl, Java, JavaScript, Visual Basic or
Scheme.  To find out more about what Python can do for you, point your
browser to http://www.python.org/.


How do I learn Python?
----------------------

The official tutorial is still a good place to start; see
http://docs.python.org/ for online and downloadable versions, as well
as a list of other introductions, and reference documentation.

There's a quickly growing set of books on Python.  See
http://wiki.python.org/moin/PythonBooks for a list.

Another good resource:
http://www.tutorialspoint.com/python/


Documentation
-------------

All documentation is provided online in a variety of formats.  In
order of importance for new users: Tutorial, Library Reference,
Language Reference, Extending & Embedding, and 
