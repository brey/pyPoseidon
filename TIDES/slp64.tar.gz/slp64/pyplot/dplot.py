# Pyton/matplotlib program: dplot
# input options:
# 1. slp64 processing format DAT file, ie. da003.dat
# 2. csv format (output \slp64\util\dsl2csv.exe
# (can download daily file from
# http://uhslc.soest.hawaii.edu/data/download/rq or fd
# then rename to slp64 name convention, (ie rqd0238a.csv to da238.csv)
#
# option for all or select years
#
# output is a online figure and also saved to file root.png,
# eg, da238.csv -> da238.png
#
# P.Caldwell 2014/09/19-22
#
import os, sys
import matplotlib.pyplot as plt
from  matplotlib import ticker
from matplotlib.ticker import ScalarFormatter, MaxNLocator
import numpy as np
# for get_dday
import datetime
from matplotlib.dates import date2num
from matplotlib.dates import MonthLocator, WeekdayLocator, DateFormatter

def get_dday(timetag, yearbase):
    epoch_t = date2num( datetime.datetime(yearbase, 1, 1) )
    year, month, day = timetag
    yy, mm, dd = int(year), int(month), int(day)
    thisday_t = date2num( datetime.datetime( yy, mm, dd ) )
    diff_days = thisday_t - epoch_t
    return diff_days

# interactive input and file open
print '\n\nPLOT DAILY SEA LEVEL FOR ONE STATION\n\n'
print  'Input file must be in directory /slp64/dat\n\n'
vstn =  raw_input(
    'Enter input daily data file version and station number, eg. a003: ')
# interactive input test
tcnt = 0
while tcnt < 5:
   if len(vstn) == 4:
       break
   else:
       print '\n\n input must be exactly 4 alphanumerics, try again\n\n'
       vstn =  raw_input(
          'Enter input daily data file version and station number, eg. a003: ')
       tcnt +=1

print '\n\nChoose number below for input data file format\n'
ift  =  raw_input(
    '1: SLP64 dat (eg da003.dat) or   2: csv (eg da003.csv)          : ')
# interactive input test
tcnt = 0
while tcnt < 5:
   if int(ift) == 1 or int(ift) == 2:
       break
   else:
       print '\n\n input must be a 1 or 2, try again\n\n'
       ift  =  raw_input(
          '1: SLP64 dat (eg da003.dat) or   2: csv (eg da003.csv)          : ')
       tcnt +=1

if int(ift) == 1:
   iotmp = open( 'tvstn.txt',  'w')
   iotmp.write( vstn )
   iotmp.close()
   # convert dat file to csv, delete when done at end
   os.system( 'src/ddat2csv.exe' )
   path_infile = '../dat/t'   #windows
#  path_infile = '/slp64/dat/t'      #unix
   infile = path_infile + vstn + '.csv'
   fo_inf = open( infile, 'r' )
else:
   path_infile = '../dat/d'   #windows
#   path_infile = '/slp64/dat/d'     #unix
   infile = path_infile + vstn + '.csv'
   fo_inf = open( infile, 'r' )
#
#definitions
years = []
data = []
subdata = []

#read in full file and set start year
fo_inf = open(infile,'r')
lines=fo_inf.readlines()
fo_inf.close()
yearbase=int(lines[0].split(',')[0])

# assemble data
for line in lines:
     year, month, day, val = line.split(',')
     if year not in years:
          years.append(year)
     data.append([get_dday([year,month, day], yearbase), int(val)])

print '\n\n+++++++++++++++++++++++++++++++++'
print 'Span of years: ', years[0], ' - ', years[-1]
numyrs = (int(years[-1]) -  int(years[0])) + 1
print 'Length of span in years:  %.3d '% numyrs
print '+++++++++++++++++++++++++++++++++\n\n'
print 'Choose number below for option of years in plot\n'
ioptyrs  =  raw_input(
    '1: all years    or   2: select years          : ')
# interactive input test
tcnt = 0
while tcnt < 5:
   if int(ioptyrs) == 1 or int(ioptyrs) == 2:
       break
   else:
       print '\n\n input must be a 1 or 2, try again\n\n'
       ioptyrs  =  raw_input(
           '1: all years    or   2: select years          : ')
       
if int(ioptyrs) == 2:
    print '\nProvide desired range of years\n'
    istryr = raw_input(
        'Enter start year, ie 1992 : ')
    iendyr = raw_input(
        'Enter end year,   ie 1995 : ')
    numyrs = (int(iendyr) - int(istryr)) + 1
    print 'Subset number of years    :  %.3d' %  numyrs
    for line in lines:
        year, month, day, val = line.split(',')
        if (int(year) >= int(istryr)) and (int(year) < (int(iendyr)+1)):
           subdata.append([get_dday([year,month, day], int(istryr)), int(val)])

# make np array for all or subset years
if int(ioptyrs) == 1:
   adata=np.array(data)
   days = adata[:,0]
   pdays=yearbase + days/365.
   tityr = yearbase
elif int(ioptyrs) == 2:
   adata=np.array(subdata)
   days = adata[:,0]
   pdays=int(istryr) + days/365.
   tityr = int(istryr)

# flag for missing data
vals = np.ma.masked_where(adata[:,1] == 9999, adata[:,1])

#check if first value of rang is missing, since pyplot bombs if so
if adata[0,1] == 9999:
   vals[0] = vals.mean()
    
## plot it
f,ax=plt.subplots()
slmean = vals.mean()

ax.plot(pdays, vals, 'k')
slmean = vals.mean()


# X axis special case if one year span
if numyrs == 1:
     dnum = []
     dlen = len(days)
     id = 0
     while id < dlen:
        dtmp1 = datetime.date.fromordinal(
                         datetime.date( tityr, 1, 1).toordinal()
                              + int(days[id]) - 1  )
        dnum.append(  date2num(dtmp1)  )
        id +=1

     ax.set_xlim(dnum[0], dnum[-1])
     ax.plot_date(dnum, vals, 'k')
     ax.xaxis.set_major_formatter(ScalarFormatter(useOffset = False))
     months = MonthLocator( bymonthday=1, interval=1)
     monthsFmt = DateFormatter("%b")
     ax.xaxis.set_major_locator( months )
     ax.xaxis.set_major_formatter( monthsFmt  )
     ax.autoscale_view()
     ax.set_title('Daily Sea Level Series: ' + vstn + '    Year: %d' % tityr ) # TITLE
else:
   ax.set_xlabel('Year')
   ax.set_xlim(pdays[0], pdays[-1])
   ax.xaxis.set_major_formatter(ScalarFormatter(useOffset = False))
   ax.set_title('Daily Sea Level Series: ' + vstn) # TITLE

# Y-axis
ax.set_ylim(min(vals), max(vals)+5)
ax.set_ylabel('Height (mm)')
ax.yaxis.set_major_formatter(ScalarFormatter(useOffset = False))

ax.hlines(slmean, min(pdays), max(pdays), color=[.8,.8,.8], lw=2)
f.text(.98, .5, '  mean\n%5.1f' % (vals.mean()), ha='right', 
           fontsize=10)
plt.grid(True)
f.savefig('plots/d'+vstn+'.png' )
plt.show()

#input file cleanup
if int(ift) == 1:
   os.system( 'rm tvstn.txt ')
   delcom = 'rm ' + infile
   os.system( delcom )
