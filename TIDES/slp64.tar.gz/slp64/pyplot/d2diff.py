# Python/matplotlib program: plot 2 Daily series and their difference
# input options:
# 1. slp64 processing format DAT file, ie. da003.dat
# 2. csv format (output \slp64\util\dsl2csv.exe
# (can download daily file from
# http://uhslc.soest.hawaii.edu/data/download/rq or fd
# then rename to slp64 name convention, (ie rqd0238a.csv to da238.csv)
#
# option for all or select years
#
# output is a online figure and also saved to file root.jpg,
# eg, da238.csv -> da238.jpg
#
# P.Caldwell 2014/09/29
#
import os, sys
import matplotlib.pyplot as plt
from  matplotlib import ticker
from matplotlib.ticker import ScalarFormatter, MaxNLocator
import numpy as np
# for get_dday
import datetime
from matplotlib.dates import date2num
from matplotlib.dates import MonthLocator, WeekdayLocator, DateFormatter
# for NaN
from pylab import *
import math

def get_dday(timetag, yearbase):
    epoch_t = date2num( datetime.datetime(yearbase, 1, 1) )
    year, month, day = timetag
    yy, mm, dd = int(year), int(month), int(day)
    thisday_t = date2num( datetime.datetime( yy, mm, dd ) )
    diff_days = thisday_t - epoch_t
    return diff_days

# interactive input and file open
print '\n\nPLOT DAILY SEA LEVEL FOR TWO STATIONS AND DIFFERENCE\n\n'
print  'Input file must be in directory ../slp64/dat\n\n'
vstn1 =  raw_input(
    'Enter 1st input daily data file version and station number, eg. a003: ')
# interactive input test
tcnt = 0
while tcnt < 5:
   if len(vstn1) == 4:
       break
   else:
       print '\n\n input must be exactly 4 alphanumerics, try again\n\n'
       vstn1 =  raw_input(
          'Enter 1st input daily data file version and station number, eg. a003: ')
       tcnt +=1

# 2nd series
vstn2 =  raw_input(
    '\n\nEnter 2nd input daily data file version and station number, eg. a003: ')
# interactive input test
tcnt = 0
while tcnt < 5:
   if len(vstn1) == 4:
       break
   else:
       print '\n\n input must be exactly 4 alphanumerics, try again\n\n'
       vstn2 =  raw_input(
          'Enter 2nd input daily data file version and station number, eg. a003: ')
       tcnt +=1

print '\n\nChoose number below for input data file format (same both series)\n'
ift  =  raw_input(
    '1: SLP64 dat (eg da003.dat) or   2: csv (eg da003.csv)          : ')
# interactive input test
tcnt = 0
while tcnt < 5:
   if int(ift) == 1 or int(ift) == 2:
       break
   else:
       print '\n\n input must be a 1 or 2, try again\n\n'
       ift  =  raw_input(
          '1: SLP64 dat (eg da003.dat) or   2: csv (eg da003.csv)          : ')
       tcnt +=1
# 1st series open, read in, build arrays ************************************
if int(ift) == 1:
   iotmp = open( 'tvstn.txt',  'w')
   iotmp.write( vstn1 )
   iotmp.close()
   # convert dat file to csv, delete when done at end
   os.system( 'src/ddat2csv.exe' )
   os.system( 'rm tvstn.txt ')
   path_infile1 = '../dat/t'
   infile1 = path_infile1 + vstn1 + '.csv'
else:
   path_infile1 = '../dat/d'
   infile1 = path_infile1 + vstn1 + '.csv'
#
#definitions
years1 = []
data1 = []
subdata1 = []

#read in full file and set start year
fo_inf1 = open(infile1,'r')
lines1=fo_inf1.readlines()
fo_inf1.close()
yearbase1=int(lines1[0].split(',')[0])

# assemble data
for line in lines1:
     year1, month1, day1, val1 = line.split(',')
     if year1 not in years1:
          years1.append(year1)
#     data1.append([get_dday([year1, month1, day1], yearbase1), int(val1)])

print '\n\n+++++++++++++++++++++++++++++++++++++++++++++++'
print 'Series ', vstn1, ' Span of years: ', years1[0], ' - ', years1[-1]
numyrs1 = (int(years1[-1]) -  int(years1[0])) + 1
print 'Length of span in years:        %.3d '% numyrs1
print '+++++++++++++++++++++++++++++++++++++++++++++++\n\n'

# 1st Series input end ******************************************
# 2nd Series input begin ******************************************
if int(ift) == 1:
   iotmp = open( 'tvstn.txt',  'w')
   iotmp.write( vstn2 )
   iotmp.close()
   # convert dat file to csv, delete when done at end
   os.system( 'src/ddat2csv.exe' )
   os.system( 'rm tvstn.txt ')
   path_infile2 = '../dat/t'
   infile2 = path_infile2 + vstn2 + '.csv'
else:
   path_infile2 = '../dat/d'
   infile2 = path_infile2 + vstn2 + '.csv'
#
#definitions
years2 = []
data2 = []
subdata2 = []

#read in full file and set start year
fo_inf2 = open(infile2,'r')
lines2=fo_inf2.readlines()
fo_inf2.close()
yearbase2=int(lines2[0].split(',')[0])

# assemble data
for line in lines2:
     year2, month2, day2, val2 = line.split(',')
     if year2 not in years2:
          years2.append(year2)
#     data2.append([get_dday([year2, month2, day2], yearbase2), int(val2)])

print '\n\n+++++++++++++++++++++++++++++++++++++++++++++++'
print 'Series ', vstn2, ' Span of years: ', years2[0], ' - ', years2[-1]
numyrs2 = (int(years2[-1]) -  int(years2[0])) + 1
print 'Length of span in years:        %.3d '% numyrs2
print '+++++++++++++++++++++++++++++++++++++++++++++++\n\n'
# 2nd Series input end ******************************************

print '\n\nChoose overlapping years for plot\n'
print 'Program does not work if one or both series has all missing data'
print 'in your chosen span.'
istryr = raw_input(
     'Enter start year, ie 1992 : ')
iendyr = raw_input(
     'Enter end year,   ie 1995 : ')
numyrs = (int(iendyr) - int(istryr)) + 1
print '\n\nSubset number of years    :  %.3d' %  numyrs
for line in lines1:
    year1, month1, day1, val1 = line.split(',')
    if (int(year1) >= int(istryr)) and (int(year1) < (int(iendyr)+1)):
       subdata1.append([get_dday([year1,month1, day1], int(istryr)), int(val1)])
for line in lines2:
    year2, month2, day2, val2 = line.split(',')
    if (int(year2) >= int(istryr)) and (int(year2) < (int(iendyr)+1)):
       subdata2.append([get_dday([year2,month2, day2], int(istryr)), int(val2)])

# make np array for subset years
adata1=np.array(subdata1)
days1 = adata1[:,0]
vald1 = adata1[:,1]  #for diff
pdays1=int(istryr) + days1/365.
adata2=np.array(subdata2)
days2 = adata2[:,0]  
vald2 = adata2[:,1] #for diff
pdays2=int(istryr) + days2/365.

tityr = int(istryr)

# flag for missing data
vals1 = np.ma.masked_where(adata1[:,1] == 9999, adata1[:,1])
vals2 = np.ma.masked_where(adata2[:,1] == 9999, adata2[:,1])

# difference
dfdays = []
dfvals = []
isd1 = len(days1)
isd2 = len(days2)
isc1 = 0
while isc1 < isd1:
    dfdays.append( days1[isc1] )
    if ( int(vald1[isc1]) == 9999 ) or (int(vald2[isc1]) == 9999 ):
       dfvals.append( 9999 )
    else:
       dfvals.append( vald1[isc1] - vald2[isc1] )
    isc1 +=1

# set to NaN for difference = 9999
lendfvals = len(dfvals)
iv = 0
while iv < lendfvals:
    if dfvals[iv] == 9999:
        dfvals[iv] = NaN
    iv += 1

# De-mean difference
dfmean = np.nanmean(dfvals)
df = dfvals - dfmean

# check if 1st value of series is Nan, if so, set to mean
if math.isnan( float(dfvals[0]) ) == True:
    dfvals[0] = np.nanmean(dfvals)
    df[0] = 0

#for series plot,
# check if first value of range is missing, since pyplot bombs if so
if adata1[0,1] == 9999:
   vals1[0] = vals1.mean()
if adata2[0,1] == 9999:
   vals2[0] = vals2.mean()
    
## plot two series on one plot
#  nrows=12, sharex=True)
f,ax=plt.subplots(2, sharex=True)
slmean1 = vals1.mean()
slmean2 = vals2.mean()
dm1 = vals1 - slmean1
dm2 = vals2 - slmean2

# X axis special case if one year span
if numyrs == 1:
     dnum1 = []
     dlen1 = len(days1)
     id1 = 0
     while id1 < dlen1:
        dtmp1 = datetime.date.fromordinal(
                         datetime.date( tityr, 1, 1).toordinal()
                              + int(days1[id1]) - 1  )
        dnum1.append(  date2num(dtmp1)  )
        id1 +=1

     dnum2 = []
     dlen2 = len(days2)
     id2 = 0
     while id2 < dlen2:
        dtmp2 = datetime.date.fromordinal(
                         datetime.date( tityr, 1, 1).toordinal()
                              + int(days2[id2]) - 1  )
        dnum2.append(  date2num(dtmp2)  )
        id2 +=1
        
     min1 = min(dnum1)
     min2 = min(dnum2)
     max1 = max(dnum1)
     max2 = max(dnum2)
     if min1 <= min2:
       xmin = min1
     else:
       xmin = min2
     if max1 >= max2:
       xmax = max1
     else:
       xmax = max2

     ax[0].set_xlim(xmin, xmax)
     ax[0].plot_date(dnum1, dm1, 'r', label=vstn1)
     ax[0].plot_date(dnum2, dm2, 'b', label=vstn2)
     ax[0].xaxis.set_major_formatter(ScalarFormatter(useOffset = False))
     months = MonthLocator( bymonthday=1, interval=1)
     monthsFmt = DateFormatter("%b")
     ax[0].xaxis.set_major_locator( months )
     ax[0].xaxis.set_major_formatter( monthsFmt  )
     ax[0].autoscale_view()
     ax[0].set_title('Daily Sea Level Series ' + '    Year: %d' % tityr ) # TITLE
else:
   ax[0].plot(pdays1, dm1, 'r', label=vstn1)
   ax[0].plot(pdays2, dm2, 'b', label=vstn2)

   min1 = min(pdays1)
   min2 = min(pdays2)
   max1 = max(pdays1)
   max2 = max(pdays2)
   if min1 <= min2:
     xmin = min1
   else:
     xmin = min2
   if max1 >= max2:
     xmax = max1
   else:
     xmax = max2
   
   ax[0].set_xlim( xmin, xmax )
   ax[0].xaxis.set_major_formatter(ScalarFormatter(useOffset = False))
   ax[0].set_title('Daily Sea Level Series ' ) # TITLE

# Y-axis
min1 = min(dm1)
max1 = max(dm1)
min2 = min(dm2)
max2 = max(dm2)
if min1 <= min2:
    ymin = min1
else:
    ymin = min2
if max1 >= max2:
    ymax = max1
else:
    ymax = max2
ax[0].set_ylim(ymin, ymax+5)
ax[0].set_ylabel('De-meaned Height (mm)')
ax[0].yaxis.set_major_formatter(ScalarFormatter(useOffset = False))

# ax.hlines(slmean, min(pdays), max(pdays), color=[.8,.8,.8], lw=2)
# f.text(.98, .5, '  mean\n%5.1f' % (vals.mean()), ha='right', 
#          fontsize=10)
ax[0].grid(True)
legend = ax[0].legend(loc='upper left')

# Plot difference  *************************************************
# X axis special case if one year span
if numyrs == 1:
     dndf = []
     dlendf = len(dfdays)
     idf = 0
     while idf < dlendf:
        dtmpf = datetime.date.fromordinal(
                         datetime.date( tityr, 1, 1).toordinal()
                              + int(dfdays[idf]) - 1  )
        dndf.append(  date2num(dtmpf)  )
        idf +=1

     ax[1].set_xlim(min(dndf), max(dndf) )
     ax[1].plot_date(dndf, df, 'k', label='Difference')
     ax[1].xaxis.set_major_formatter(ScalarFormatter(useOffset = False))
     months = MonthLocator( bymonthday=1, interval=1)
     monthsFmt = DateFormatter("%b")
     ax[1].xaxis.set_major_locator( months )
     ax[1].xaxis.set_major_formatter( monthsFmt  )
     ax[1].autoscale_view()

else:
     ax[1].plot(pdays1, df, 'k', label='Difference')
     ax[1].set_xlabel('Year')
     ax[1].set_xlim( min(pdays1), max(pdays1) )
     ax[1].xaxis.set_major_formatter(ScalarFormatter(useOffset = False))

# Y axis diff plot
ax[1].set_ylim(min(df), max(df)+5)
ax[1].set_ylabel('Height (mm)')
ax[1].yaxis.set_major_formatter(ScalarFormatter(useOffset = False))

ax[1].grid(True)
legend = ax[1].legend(loc='lower left')

# pau all plotting

f.savefig('plots/d'+vstn1+'_'+vstn2+'.png' )
plt.show()

#input file cleanup
if int(ift) == 1:
   delcom1 = 'rm ' + infile1
   os.system( delcom1 )
   delcom2 = 'rm ' + infile2
   os.system( delcom2 )
