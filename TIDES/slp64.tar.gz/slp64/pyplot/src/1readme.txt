               FILES ON THIS directory
FILENAME       COMMENT
------------   ------------------------------------
               Fortran source code:
hdat2csv.for   SLP64 processing format to cSV (hourly)
dday2csv.for   same daily
mday2csv.for   same monthly
