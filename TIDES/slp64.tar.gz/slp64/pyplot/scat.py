# Pyton/matplotlib program: scat
# input :
#  slp64 processing format Tide Staff - Gauge Pair file, ie. x0038507.dat
# output: 1) plot with filename root.png, eg, x0038507.png
#            in directory \slp64\pyplot\plots
#         2) summary of gauge-staff pairs in file root.out
#            in directory \slp64\cal
#
# P.Caldwell 2014/10/7
#
import matplotlib.pyplot as plt
from  matplotlib import ticker
from matplotlib.ticker import ScalarFormatter, MaxNLocator
import numpy as np

# interactive input and file open
print '\n\nSCATTER PLOT FOR TIDE GAUGE AND TIDE STAFF PAIRS\n\n'
print  'Note:\n'
print  '1. Output summary text file and plot placed in ../cal\n'
print  '2. Units of plot and output file will be same as input file\n'
print  '3. Input file must be in directory ../cal\n\n'
root =  raw_input(
    'Enter input ROOT filename, eg. x0038507  : ')
# interactive input test
tcnt = 0
while tcnt < 5:
   if len(root) == 8:
       break
   else:
       print '\n\n input must be exactly 4 alphanumerics, try again\n\n'
       root =  raw_input(
          'Enter input daily data file version and station number, eg. a003: ')
       tcnt +=1

# Input file
path_infile = '../cal/'   
infile = path_infile + root + '.dat'
fo_inf = open( infile, 'r' )

# Output text file
path_outfile = '../cal/'
outfile  = path_outfile + root + '.out'
fo_out = open( outfile, 'w' )
#
#definitions
stafflow = []
staffhigh = []
staffave = []
gauge = []
diff = []

#read in full file and set start year
fo_inf = open(infile,'r')
lines=fo_inf.readlines()
fo_inf.close()
plot_title=lines[0]

# Output title and header
fo_out.write('SUMMARY STATISTICS FOR TIDE GAUGE - TIDE STAFF PAIRS\n\n')
fo_out.write(plot_title)
fo_out.write('\n Number of Gauge-Staff pairs: %4d\n\n' % (len(lines) - 1) )
fo_out.write('        <-  TIDE STAFF   ->')
fo_out.write('\n        L0W    HIGH     AVE   GAUGE    DIFF\n')

# assemble data
for line in lines[1:]:
     lo, hi, gval = line.split()
     stafflow.append( int(lo) )
     staffhigh.append( int(hi) )
     ave = (int(lo) + int(hi)) / 2.0
     df = float(gval) - ave
     staffave.append( ave )
     gauge.append( int(gval) )
     diff.append( df )
     # sb = ( lo, hi, ave, gauge, diff, '\n' )
     # s = str(sb)
     #fo_out.write( s )
     fo_out.write( '    %7d %7d %7d %7d %7d\n' %
           (int(lo), int(hi), int(ave), int(gval), int(df) ) )

fo_out.write('\nAVE %7d %7d %7d %7d %7d\n' %
          ( np.mean(stafflow),
            np.mean(staffhigh),
            np.mean(staffave),
            np.mean(gauge),
            np.mean(diff) ) )
fo_out.write('\n\nRemove outlier pairs from ' + infile + ' and rerun SCAT\n\n')
fo_out.write(
   'After clean pair file obtained, suggested Preliminary Calibration:\n')
fo_out.write(
   'Subtract AVE DIFF from each gauge value to link to tide staff zero.\n')
fo_out.close()
  
## plot it
f,ax=plt.subplots()
ax.plot(gauge, staffave, 'k*')
ax.set_title( plot_title ) # TITLE

# X-axis
ax.set_xlabel('Tide Gauge Values')
ax.set_xlim( min(gauge) - 2, max(gauge) + 2 )
ax.xaxis.set_major_formatter(ScalarFormatter(useOffset = False))

# Y-axis
ax.set_ylim(min(staffave) - 2, max(staffave) + 2)
ax.set_ylabel('Staff')
ax.yaxis.set_major_formatter(ScalarFormatter(useOffset = False))

plt.grid(True)
f.savefig('../cal/'+root+'.png' )
plt.show()
