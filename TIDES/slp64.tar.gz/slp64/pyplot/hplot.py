# Python/matplotlib program: hplot
# input options:
# 1. slp64 processing format DAT file, ie. va00385.dat (observed data)
#                                          ra00385.dat (residuals)
# 2. csv format (output \slp64\util\hsl2csv.exe
#
# output is a online figure and also saved to file directory plot/root.jpg,
# eg, ra00385.dat -> ra00385.jpg
#
# P.Caldwell 2014/09/23
#
import os, sys
import matplotlib.pyplot as plt
from  matplotlib import ticker
from matplotlib.ticker import ScalarFormatter, MaxNLocator
import numpy as np

def get_one_month_hourdata(adata, month):
    '''
    adata is [month, day, hour, value]
    return decimal days and tide values
    '''
    subset_index = np.where(adata[:,0] == int(month))[0]
    dmt = adata[subset_index][:,1:] #day hour tide
    day = ( dmt[:,0] + dmt[:,1]/24. ) - 1.
    return day, np.ma.masked_where(dmt[:,-1]==9999, dmt[:,-1])

def plot_ax(ax, days, tidevals, spread):
    ''' plot tide heights; plot +/- spread from mean
    '''
    ## plot it
    ax.plot(days, tidevals, 'k')
    tidemean = tidevals.mean()
    ax.set_xlim(1,31)
    ax.hlines(tidemean, 1,31, color=[.8,.8,.8], lw=2)
    ax.xaxis.set_major_formatter(ScalarFormatter(useOffset = False))
    ax.yaxis.set_major_formatter(ScalarFormatter(useOffset = False))
    ax.set_yticks([ int(tidemean),])
    ax.set_ylim(tidemean-spread, tidemean+spread)
    ax.set_xticks(np.arange(32))

def plot_hourlytides(adata, spread ):
    months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 
              'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']

    f, ax = plt.subplots(figsize=(12,8), nrows=12, sharex=True)

    # loop for each month
    for pnum in np.arange(12):
        imon=pnum+1
        days, tidevals=get_one_month_hourdata(adata, imon)

        # if complete month of 9999s, set all to 0
        lenval = len(tidevals)
        icnt = 0
        tcnt = 0
        while icnt < lenval:
           tst= np.ma.getmask(tidevals[icnt])
           if tst == True:
               tcnt += 1
           icnt += 1
        if tcnt == lenval:   # all month 9999s
           # print 'full mon missing'
           icnt = 0
           while icnt < lenval:
               tidevals[icnt] = 9999
               icnt += 1
        else:   # see if 1st val of month = 9999
           tst= np.ma.getmaskarray(tidevals)
           # print 'imon=, tst=', imon, tst[0]
           tst1 = tst[0]
           if tst1 == True:
              tidevals[0] = tidevals.mean()
              # print 'tidevals[0]=', tidevals[0]

        plot_ax( ax[pnum], days, tidevals, spread )
        ax[pnum].text(31.4, tidevals.mean(), months[pnum], fontsize=9)
        ax[pnum].tick_params(axis='both', which='major', labelsize=8)
        ax[pnum].set_xticklabels([])
        tidemean = tidevals.mean()
    return f,ax,tidemean

# interactive input and file open
print '\n\nPLOT HOURLY SEA LEVEL FOR ONE YEAR OF ONE STATION\n\n'
print  'Input file must be in directory /slp64/dat\n\n'

froot =  raw_input('Enter input filename root,ie va00385 or ra00385     : ')
tcnt = 0
while tcnt < 5:
   if len(froot) == 7:
       break
   else:
       print '\n\n input root file must be exactly 7 alphanumerics, try again\n\n'
       froot =  raw_input('Enter input filename root,ie va00385 or ra00385     : ')
       tcnt +=1
resid = froot[0]

print '\n\nChoose number below for input data file format\n'
ift  =  raw_input('1: SLP64 dat (va00385.dat) or   2: csv (va00385.csv): ')
tcnt = 0
while tcnt < 5:
   if int(ift) == 1 or int(ift) == 2:
       break
   else:
       print '\n\n input must be a 1 or 2, try again\n\n'
       ift  =  raw_input('1: SLP64 dat (va00385.dat) or   2: csv (va00385.csv): ')
       tcnt +=1

# Input option for Y-axis range
print '\n\nY-axis plot range options:'
spread_choices = ['+-  400 mm (best for residuals)',
                  '+- 1000 mm (small tide range)',
                  '+- 2000 mm (medium tide range)',
                  '+- 3000 mm (large tide range)',
                  '+- 4000 mm (extreme tide range)' ]
spread_values = [ 400, 1000, 2000, 3000, 4000 ]
r = range(5)
for i in r:
     print i+1, spread_choices[i]
iop_spread =  raw_input('Enter Y-axis option number (1-5): ')
tcnt = 0
while tcnt < 5:
   if int(iop_spread) >= 1 and int(iop_spread) <= 5:
       break
   else:
       print '\n\n input must be a number within 1 to 5, try again\n\n'
       iop_spread =  raw_input('Enter Y-axis option number (1-5): ')
   tcnt += 1

if int(ift) == 1:
   iotmp = open( 'troot.txt',  'w')
   iotmp.write( froot )
   iotmp.close()
   # convert dat file to csv, delete when done at end
#  print 'debug before os'
   os.system( 'src/hdat2csv.exe' )
   path_infile = '../dat/t' #linux
   infile = path_infile + froot[1:] + '.csv'
else:
   path_infile = '../dat/' #linux
   infile = path_infile + froot + '.csv'

#read in full file and set start year
fo_inf = open(infile,'r')
lines=fo_inf.readlines()
fo_inf.close()
yearbase=int(lines[0].split(',')[0])

# assemble data
data = []
for line in lines:
    parts = line.split(',')
    if int(parts[0]) == yearbase:
       parts = line.split(',')[1:] #strip year
       ints = []
       for s in parts:
           ints.append(int(s))
       data.append(ints)
            
# convert to numpy array
adata=np.array(data)

# prepare plot
spread = spread_values[ int(iop_spread)-1 ]
f,ax,tidemean = plot_hourlytides(adata, spread )

# location of numbers below x-axis varies as function of spread and tidemean
x_lab_loc = tidemean - spread - (0.6*spread)
for num in range(1,32):
    ax[-1].text(num-0.3, x_lab_loc, str(num), ha='right', fontsize=8) 

vstn = froot[1:5]
if resid == 'r': 
    ax[0].set_title('Residuals Series: '+vstn +'  Year: %d' % int(yearbase) )
else:
   ax[0].set_title('Observed Hourly Data Series: '+vstn+'  Year: %d' % int(yearbase) )
f.text(.05,.95,'mean +/- %2.0fmm' % (spread) )

f.savefig('plots/'+froot+'.png' )
plt.show()

#input file cleanup
if int(ift) == 1:
   os.system( 'rm troot.txt ')
   delcom = 'rm '+infile
   os.system( delcom )
