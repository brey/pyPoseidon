# Python program to fill short gaps with Predicted Tide Method

import os, sys
import re

# first delete any existing files that the fortran program will create
os.system( 'ls ../dat/extra.dat > tmpfiles.lst' )
lines=open('tmpfiles.lst','r').readlines()
for line in lines:
   if re.match('../dat/extra.dat', line):
      os.system('rm ' + line)
os.system( 'rm tmpfiles.lst' )
#
os.system( 'ls gapnotes/timing.txt > tmpfiles.lst' )
lines=open('tmpfiles.lst','r').readlines()
for line in lines:
   if re.match('gapnotes/timing.txt', line):
      os.system('rm ' + line)
os.system( 'rm tmpfiles.lst' )
#
# run Predicted Tide Method program
os.system( 'fallptm.exe' )
