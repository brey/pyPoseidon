               FILES ON THIS directory
FILENAME       COMMENT
------------   ------------------------------------
               Fortran source code:
RESID    FOR   SOURCE FOR CALCULATION OF RESIDUALS
COREF    FOR    "          REFERENCE LEVEL CORRECTION
FALLPTM  FOR    "          GAP FILLING
