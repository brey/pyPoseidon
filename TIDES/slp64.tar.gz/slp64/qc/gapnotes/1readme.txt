Output files from gapfall.py 


                 FILES ON THIS directory
FILENAME         COMMENT
--------------   ------------------------------------
gapsssyyyy.txt   List of gaps that have been interpolated
                 sss: station number
                 yyyy: year
timing.txt       monthly-averaged offset in timing as
                 estimated between tide gauge data and
                 predicted tides

