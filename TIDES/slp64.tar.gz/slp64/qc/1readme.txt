
Files on directory /slp64/qc   'Quality Control Procedures'

FILENAME       COMMENT
-------------  -----------------------------------
gapfall.py     python job FOR GAP FILLING
fallptm.exe    GAP FILLING
residm.exe     RESIDUAL CALCULATIONS
reflev.exe     STAFF/GAUGE STATISTICS
coref.exe      REFERENCE LEVEL CORRECTION

Notes for filling missing data gaps using "python gapfall.py"
1. To execute, enter on command prompt: python gapfall.py
2. The interpolation using the Predicted Tide Method for filling
   gaps less than 25 hours in length.
3. Input files 
                      /slp64/dat (observed hourly tide data)
                      /slp64/prd (predicted tides)
4. Output files 
                      /slp64/dat (observed hourly tide data with gaps filled)
                      though different version in filename

                      /slp64/dat file extra.dat will hold interpolated data
                    for the first two days of the following year.  If gap 
                    occurs across the year or beginning of next year, then
                    the interpolated data can be cut/paste from extra.dat
                    to the appropriate interpolated data file
                    
                      /slp64/qc/gapnotes/gapsssyyyy.txt
                      where sss: station number and yyyy is year
                      This file lists the interpolated gaps.

                      /slp64/qc/gapnotes/timing.txt
                      This file contains a monthly estimate of the timing 
                      characteristics between the observed and predicted series

5. Special Case: If you are running this program with a gap
exactly at the end of a century, first make sure that the
predicted tide file (for example qa00300.dat) does not 
have missing value (9999) at the first hour of the first
day.  If so, this value can be obtained by running the
tidal prediction program for the year prior to the new
century (eg. 1999).  The prediction program will display
the value which must be hand-edited into the prediction
file (eg. qa00300.dat).
