               FILES ON THIS directory

Fortran source code (note source code in upper case though
executable files in lower case).

Tide Analysis 
FILENAME       COMMENT
------------   ------------------------------------
aninq.for      prepare input to analysis
cvdcana.for    change to foreman format
fittide.for    primary analysis (M.Foreman software)
               gfortran -static -fno-automatic fittide.for
hcfile.for     formatting constituents into output


Tide Prediction
FILENAME       COMMENT
------------   ------------------------------------
prdnote.for    prepare for prd
parmchk.for    prepare for prd
timper.for     time span for prd set up
tidep.for      primary prediction (M.Foreman software)
               gfortran -static -fno-automatic tidep.for
prdvp.for      change output prd format to SLP64

