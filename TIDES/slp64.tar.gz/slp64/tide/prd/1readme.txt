
Files on directory /tide/prd : 'Tidal Prediction Function- Multiple Years' 


 filename        comment
------------  --------------------- 
tideprd.py    python program to execute Fortran programs (files with
              .exe) in the creation of tidal predictions for consecutive 
              years
