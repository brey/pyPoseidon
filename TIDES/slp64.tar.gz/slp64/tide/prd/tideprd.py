# Python Program: Tidal Prediction for multiple years
#
# P.Caldwell 2014/10/10
#
import os, sys
import re

# Message to user (PRDNOTE.FOR in TIDEPRD.BAT
print '\n\n           TIDAL PREDICTION                    \n\n'
print' *this version allows multiple years to be made\n\n     '
print 'Purpose: From harmonic constants computed by the       '
print '         tidal analysis program, obtain equally-spaced '
print '         or high-low predicted tides for the desired   '   
print '         year.                               \n\n  '

print 'Note : (1) Tidal predictions are calculated            '
print '       for the time period from the last day of        '
print '       the previous year to the first day of the       '
print '       following year.                                 '     
print '       (2) Also values for the following are fixed :   '
print '           *units of equally-spaced prd  =  2          '
print '            units of tidal constants     =  3          '
print '            start month of predictions   = 12          '
print '            interval between predictions = 60          '
print '            time scheme (0:1-24 1:0-23)  =  1          '
print '    *units code - 1:feet, 2:millimeters, 3:centimeters '     
print '     to alter any of these, edit \slp64\dinPRDVP.DIN'
print '       (3) Output placed in \slp64\prd \n\n '

print '         Our purpose of predictions is for creation '
print '         of residuals (observed data - predicted tides)'
print '         which are the basis for quality control.'
print '         The Foreman routine also provides the option '
print '         for the times and heights of the high and low'
print '         tides (cm).  However, these should not be used for'
print '         navigation.  To obtain official nautical tide'
print '         predictions, contact the National Ocean Service'
print '         of the National Oceanic and Atmospheric '
print '         Administration (NOAA).\n\n'

# Interactive input
print 'Interactive Input, please enter parameters as requested\n'
imo = 0
while imo < 5:
   p1 = raw_input('File version for output predicted tides file (eg. a): ')
   mo=re.match( "[a-zA-Z]", p1)
   if mo:
       break
   else:
       print '\nBad input, must be letter a-z or A-Z, try again\n'
   imo += 1
print ' \n'

p2 = raw_input('Station number (eg 003): ')
print ' \n'

p3ys = raw_input('Start year for prediction (eg 2008): ')

p3ye = raw_input('End year for prediction (eg 2008)  : ')
print ' \n'

print 'Time Zone Reference of Predictions'
print '(eg 000 for GMT or 060 for 60 E or W)'
print 'note hemisphere (E or W) not needed'
p4 = raw_input('=====> ')
print ' \n'

ict = 0
while ict < 4:
    if len(p4) == 3:
        break
    else:
        print 'Bad input, must be 3-digits, eg, 000 or 060, try again'
        p4 = raw_input('=====> ')
    ict += 1

print '\nCode for desired output type'
print '     0: high-low tidal listing'
print '     1: equally-spaced (hourly) values'
imo = 0
while imo < 5:
   p5 = raw_input('Enter code number 0 or 1 ==> ')
   mo=re.match( "[0-9]", p5)
   if mo:
       break
   else:
       print 'Bad input, must be 0 or 1 try again/n'
   imo += 1

# File cleanup if necessary
print '\n\nProgram is checking if temporary files exist from'
print 'earlier runs of tideprd.py since the embedded Fortran'
print 'programs will abort if they exist'
print 'IGNORE STATEMENTS BELOW, which occur if they do not exist, that is good!\n\n'
os.system( 'ls *  > tmpfiles.lst' )
lines=open('tmpfiles.lst','r').readlines()
for line in lines:
   if re.match('tem1.inp', line):
      os.system('rm ' + line)
   elif re.match('tem2.inp', line):
      os.system('rm ' + line)
   elif re.match('time.out', line):
      os.system('rm ' + line)
   elif re.match('year.tem', line):
      os.system('rm ' + line)
   elif re.match('TIDEDATA', line):
      os.system('rm ' + line)
   elif re.match('prdvp.inp', line):
      os.system('rm ' + line)
   elif re.match('prdvp.bug', line):
      os.system('rm ' + line)
   elif re.match('eqsprd.dat', line):
      os.system('rm ' + line)
   elif re.match('eqsdat.buf', line):
      os.system('rm ' + line)
   elif re.match('jump.inp', line):
      os.system('rm ' + line)
   elif re.match('i.prd', line):
      os.system('rm ' + line)
os.system( 'rm tmpfiles.lst' )
print '\n End Existing Files Test\n\n'

# Loop through each year
harmpath = '../harm/inp'
iy4 = int(p3ys)
while iy4 <= int(p3ye):
    # build temporary files
    iy4_st = str( iy4 )
    print '\n\nWorking on year: ', iy4_st
    pa3 = iy4_st[-2:]
    pa6 = iy4_st[:2]
    #
    fo_tm = open( 'tem1.inp', 'w' )
    fo_tm.write( pa3 )
    fo_tm.close()
    #
    fo_tm = open( 'tem2.inp', 'w' )
    fo_tm.write( pa6+p5 )
    fo_tm.close()
    #
    fo_tm = open( 'year.tem', 'w' )
    fo_tm.write( pa6 )
    fo_tm.close()
    #
    fo_tm = open( 'jump.inp', 'w' )
    fo_tm.write( p5 )
    fo_tm.close()
    #
    fo_tm = open( 'prdvp.inp', 'w' )
    fo_tm.write( p2+p1+pa3+p4+pa6 )
    fo_tm.close()
    #
    #get temporary copy of harmonic constants file
    comm1 = 'cp '+harmpath+p2+'.prd i.prd'
    os.system( comm1 )
    #
    # Set up time period for a given year of predictions
    os.system( 'timper.exe')
    #
    # prepare input file for Foreman tidal prediction
    os.system( 'cp ../../din/ASTODATA tidedata' )
    os.system( 'cat i.prd >> tidedata' )
    os.system( 'cat time.out >> tidedata' )
    #
    # Run tide prediction program
    os.system( 'tidep.exe' )
    #
    # Convert Foreman output to SLP64 format
    os.system( 'prdvp.exe' )
    #
    #File clean-up
    os.system( 'ls  > tmpfiles.lst' )
    lines=open('tmpfiles.lst','r').readlines()
    for line in lines:
       if re.match('tem1.inp', line):
          os.system('rm ' + line)
       elif re.match('tem2.inp', line):
          os.system('rm ' + line)
       elif re.match('time.out', line):
          os.system('rm ' + line)
       elif re.match('year.tem', line):
          os.system('rm ' + line)
       elif re.match('tidedata', line):
          os.system('rm ' + line)
       elif re.match('prdvp.inp', line):
          os.system('rm ' + line)
       elif re.match('prdvp.bug', line):
          os.system('rm ' + line)
       elif re.match('eqsprd.dat', line):
          os.system('rm ' + line)
       elif re.match('eqsdat.buf', line):
          os.system('rm ' + line)
       elif re.match('jump.inp', line):
          os.system('rm ' + line)
       elif re.match('i.prd', line):
          os.system('rm ' + line)
    os.system( 'rm tmpfiles.lst' )

    # Loop back for next year
    iy4 += 1
print '\n\n Output in slp64/prd\n\n'
