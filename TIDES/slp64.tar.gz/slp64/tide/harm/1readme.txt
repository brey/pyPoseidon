harmonic constituents
inpsss.prd   - input to prediction program
               sss: station number
harmsss.lis  - use for listing
