
Files on directory /slp64/tide/ana:  'Tidal Analysis Function' 


  filename      comment
------------   ------------  
tideanl  py    python driver program
aninq    exe   inquiry program
cvdcana  exe   convert data to Forman format
fittide  exe   Foreman tidal analysis program
hcfile   exe   build input file for prediction
