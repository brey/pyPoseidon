# Python program to drive execution of the Foreman Tide Analysis program

import os, sys
import re

# first delete any existing files that the fortran programs will create
os.system( 'ls > tmpfiles.lst' )
lines=open('tmpfiles.lst','r').readlines()
for line in lines:
   if re.match('aninq.inp', line):
      os.system('rm ' + line)
   elif re.match('cvdcana.inp', line):
      os.system('rm ' + line)
   elif re.match('dcantem.inp', line):
      os.system('rm ' + line)
   elif re.match('hcfile.inp', line):
      os.system('rm ' + line)
   elif re.match('resid.tem', line):
      os.system('rm ' + line)
   elif re.match('cancnvo.dat', line):
      os.system('rm ' + line)
   elif re.match('cvdcana.bug', line):
      os.system('rm ' + line)
   elif re.match('TGOUTPUT', line):
      os.system('rm ' + line)
   elif re.match('TIDEGDAT', line):
      os.system('rm ' + line)
   elif re.match('TIDEDAT1', line):
      os.system('rm ' + line)
   elif re.match('TIDEDAT2', line):
      os.system('rm ' + line)
   elif re.match('TIDEDAT3', line):
      os.system('rm ' + line)
os.system( 'rm tmpfiles.lst' )
#
# obtain info from users and convert to Foreman format
os.system('aninq.exe')
os.system('cvdcana.exe')
#
# setup input file for Foreman program
os.system('cp dcantem.inp TIDEGDAT')
os.system('cat cancnvo.dat >> TIDEGDAT')
#
# Foreman program
os.system('fittide.exe')
#
# Build harmonic constituent output files
os.system('hcfile.exe')
#
# file cleanup
os.system( 'ls > tmpfiles.lst' )
lines=open('tmpfiles.lst','r').readlines()
for line in lines:
   if re.match('aninq.inp', line):
      os.system('rm ' + line)
   elif re.match('cvdcana.inp', line):
      os.system('rm ' + line)
   elif re.match('dcantem.inp', line):
      os.system('rm ' + line)
   elif re.match('hcfile.inp', line):
      os.system('rm ' + line)
   elif re.match('resid.tem', line):
      os.system('rm ' + line)
   elif re.match('cancnvo.dat', line):
      os.system('rm ' + line)
   elif re.match('cvdcana.bug', line):
      os.system('rm ' + line)
   elif re.match('TGOUTPUT', line):
      os.system('rm ' + line)
   elif re.match('TIDEGDAT', line):
      os.system('rm ' + line)
   elif re.match('TIDEDAT1', line):
      os.system('rm ' + line)
   elif re.match('TIDEDAT2', line):
      os.system('rm ' + line)
   elif re.match('TIDEDAT3', line):
      os.system('rm ' + line)
os.system( 'rm tmpfiles.lst' )


