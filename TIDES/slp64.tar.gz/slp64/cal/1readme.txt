Subdirectory /slp64/cal is used to hold calibration files:

*note, Linux is case sensative in file names.

1) PAIR file: xsssyymm.dat

naming convention:  x: fixed (always "x")
       sss is station numer, eg. 003
       yy is the year (last two digits, eg 78)
       mm is the month

The PAIR file holds the tide staff readings (highs and lows)
and corresponding gauge observations.  


Record 1: Header 

Record 2 TO N:      byte          contents
                  --------- -----------------------------------
                    1-4           highest readings
                    5-8           lowest readings
                                  Note if only one reading; both the same
                    9-13          gauge value     

Example:
 STATION 30 SANTA CRUZ   01 JUL - 01 AUG 1988
 250 250 1281
 330 330 1373
.
.
 570 570 1602         
 360 360 1400



2) Long-term Log Files
After each month, or extended period of tide staff readings during which
no change occurred to the staff or the gauge, add AVE DIFF into file 
calsss.log.
