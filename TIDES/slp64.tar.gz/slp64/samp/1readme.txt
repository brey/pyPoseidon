
Files on directory /slp64/samp: 'Sample Data Files'

name            size       comment
------------  -------  ----------------------------------------------------
cal003   log            Example of a calibration log file
va00385  dat    52644   Observed hourly observations for Baltra during 1985
                        note it starts in March
va00386  dat    62812   Observed hourly observations for Baltra during 1986
                        (The above to files can be used as input to the
                        Tidal Analysis, Hourly Plot, Quality Control, or
                        Filtering programs) (NOTE THIS FILE HAS BEEN
                        INTENTIONALY CORRUPTED WITH BAD DATA TO USE AS
                        AN EXAMPLE)
ra00385  JPG            Plot of hourly residuals (output HPLOT)
va00385  JPG            Plot of hourly tide data (output HPLOT)

harm003  lis     6186   Listing of harmonic constituents for Baltra
                        (output of Tidal Analysis)
inp003   prd     5715   Harmonic constituents (output from Tidal Analysis
                        and input for Tidal Prediction)
v0038509 dat     5167   SAMPLE MONTHLY DATA FILE
da003    dat     5548   DAILY DATA FILE   (output FILTHR)
da003    jpg            Plot of daily data (output DPLOT)
db057_da061 jpg         difference plot daily (output D2DIFF)
ma003    dat      254   MONTHLY DATA FILE (output FILTHR)
ma003    jpg            Plot of montly data (output MPLOT)
mb057_ma061 jpg         difference plot monthly (output M2DIFF)
x0038807 dat      554   STAFF/GAUGE PAIR DATA FILE (input SCAT)
x0038807 out        2   Summary statistics calibration pairs (output SCAT)
x0038807 jpg       70   scatter plot of calibration pairs (output SCAT)

kwaj2014 txt            sample of hourly data downloaded from
                        NOAA/NOS/COOPS water level set for Kwajalein 2014
                        Note, last column (water level) does not have
                        fixed column positions.  Must run 
                        ../util/nos_to_fixed_columns.py.
                        Also, note NOS missing data flag is "- ",
                        which is fixed to 9.999

kwaj14fix txt            This is output from nos_to_fixed_columns.py
                        One can use DTDCNV.NOS (copy it to dtdcnv.din first)
                        with ../util/convert.py to place in SLP64 format

fdh0001  csv            hourly data downloaded from UHSLC Fast Delivery,
                        CSV option, http://uhslc.soest.hawaii.edu/data/download/fd
                        Note columns do not line up.  
                        Use ../util/csv_to_fixed_columns.py
                        (fdh0001.csv must be on ../dat to run it)
fix001   csv            Output of csv_to_fixed_columns.py
                        Note: columns now line up.
                        in ../din, copy dtdcnv.op1 dtdcnv.din
                        then run ../util/convert.py to make SLP64 format

