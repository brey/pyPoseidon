               FILES ON THIS directory
FILENAME       COMMENT
------------   ------------------------------------
filthr.for     Fortran source code:
               filter hourly into daily and monthly data