Files on directory /slp64/filt: 'Filtering Procedures'

FILENAME           COMMENT
-------------    -----------------------------------
filthr.exe     Filter from hourly into daily and monthly means

Directory src/ contains the Fortran source code

Executable was compiled with 
gfortran -static filthr.for -o filthr.exe

