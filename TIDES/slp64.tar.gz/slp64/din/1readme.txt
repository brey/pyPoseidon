
Files in Directory /slp64/din: 'Data INformation file'

  filename       comment
------------     ------------  
stainfo  din     station information file
                *station numbers as provided with SLP64 are based on
                 University of Hawaii assignments-- Users are free
                 to change any stations or numbers as desired

prdvp.din        settings for output of Foreman tidal predictions

ASTOGDAT         standard constituents used by Foreman tidal analysis 
                 DO NOT ALTER
ASTODATA         standard constituents used by Foreman tidal prediction
                 DO NOT ALTER

                 The following are used when converting format to SLP64
                 from originator's format (slp64/util/convert.py)

dtdcnv.din       settings for input format to program dtdcnv.exe
                 this file must exist for convert.py to run

dtdcnv.op1       options fixed for option 1 of slp64/util/convert.py
dtdcnv.op2       options fixed for option 2 of slp64/util/convert.py
dtdcnv.op3       options fixed for option 3 of slp64/util/convert.py
dtdcnv.op4       options fixed for option 4 of slp64/util/convert.py
                 *use program slp64/util/csv_to_fixed_columns.py
                  if mm dd and hh do not have 2 positions each
                  and the columns of each parameter do not line up
                 *double check your date values (yyyy mm dd hh)
                  have the same order and spacing (single character
                  position) as these options; otherwise,
                  edit the column positions of the dates and tide values
                 *copy to dtdcnv.din before running convert.py
                  eg, copy dtdcnv.op2 dtdcnv.din if using option 2

                  Sample originator data files as yyyy mm dd hh tide-value:
                  note 1. space between variables can be anything (comma,
                          dash, space, etc), since it is ignored
                  note 2. all show missing data options, either flag values 
                         (9999 etc) or absence of date value row (see day 2)
                  note 3. this is just a small example, most data series
                          much are longer than a few days
dtdcnv.nos        catered to format of NOAA NOS hourly data; must run
                  slp64/util/nos_to_fixed_columns.py
                  (makes output with same columns as dtdcnv.op1) 

sample_op1.txt    option 1   Examples of options 1-4 (dtdcnv.op[1-4]
sample_op3.txt    option 2
sample_op3.txt    option 3
sample_op4.txt    option 4
