# Python program to create blocks of months with missing data flags

import os, sys
import re

# test if ../dat/fill.dat if exist, if so, delete it
os.system( 'ls ../dat/fill.dat > tmpfiles.lst' )
lines=open('tmpfiles.lst','r').readlines()
for line in lines:
   if re.match('../dat/fill.dat', line):
      os.system('rm ' + line)
os.system( 'rm tmpfiles.lst' )
#
# run program to create blocks of missing months
os.system( 'fillvm.exe' )
