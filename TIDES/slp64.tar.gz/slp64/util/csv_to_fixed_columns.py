# convert CSV file to fixed columns for yyyy mm dd hh value
#
# P.Caldwell 2014/10/16
#
import os, sys
import re

# Message to user 
print '\n\n     Convert CSV to fixed-column-positioned file \n\n'

# Interactive input
print 'Interactive Input, please enter parameters as requested\n'

orgfn = raw_input('Originator CSV filename (in ../dat) : ')
print ' \n'
ismiss = raw_input(
     'Is there a missing flag data? (Y for yes, any key for no): ')
icnt = 0
while icnt < 5:
    if len(ismiss) == 1:
       break
    else:
       print 'Bad input, must be 1 character, try again Y or N'
       ismiss = raw_input('=============> ')
    icnt += 1
tmiss = 0
if ismiss == 'y' or ismiss == 'Y':
     tmiss = 1
     print ' \n'
     miss = raw_input('    Enter missing Data Flag : ')
print ' \n'

newfn = raw_input('Output filename (into ../dat) : ')
print ' \n'

print '\nCode for number of decimals  '
print '     1: none, eg, 1532, 5 positions max, output will have flag 9999'
print '     2: one, eg, 241.1, 6 positions max, output flag ==> 999.9'
print '     3: three,eg 24.142,7 positions max, output flag 99.999'
print '     4: three,eg  4.142,5 positions max, output flag  9.999'
imo = 0
while imo < 5:
   datacode = raw_input('Enter code number (1, 2, 3, or 4) ==> ')
   mo=re.match( "[0-9]", datacode)
   if mo:
      break
   else:
      print '\nBad input, must be a number from 1 to 4, try again\n'
   imo += 1
icnt = 0
while icnt < 5:
   if int(datacode) == 1:
      break
   elif int(datacode) == 2:
      break
   elif int(datacode) == 3:
      break
   elif int(datacode) == 4:
      break
   else:
      print 'Bad input, must be 1, 2, 3, or 4 try again'
      datacode = raw_input('Enter code number  ==> ')
   icnt += 1

# Open files
oripath = '../dat/'
fo_in = open( oripath+orgfn, 'r' )
f_out = open( oripath+newfn, 'w' )
#read input file
lines=fo_in.readlines()
 
## write out
for line in lines:
     year, month, day, hour, value = line.split(",")
     iyr = int(year)
     imn = int(month)
     idy = int(day)
     ihr = int(hour)
     cyear = '%4d' % iyr
     cmonth = '%2d' % imn
     cday = '%2d' % idy
     chour = '%2d' % ihr
     
     if int(datacode) == 1:
          if tmiss == 1:
              if re.match( miss, value ):
                  ival = 9999
              else:
                  ival = int( value )
          else:
              ival = int( value )         
          buf = cyear+','+cmonth+','+cday+','+chour+',%5d\n' % ival 
          f_out.write( buf )

     elif int(datacode) == 2:
          if tmiss == 1:
              if re.match( miss, value ):
                  rval = 999.9
              else:
                  rval = float( value )
          else:
              rval = float( value )         
          buf = cyear+','+cmonth+','+cday+','+chour+',%6.1f\n' % rval 
          f_out.write( buf )

     elif int(datacode) == 3:
          if tmiss == 1:
              if re.match( miss, value ):
                  rval = 99.999
              else:
                  rval = float( value )
          else:
              rval = float( value )         
          buf = cyear+','+cmonth+','+cday+','+chour+',%7.3f\n' % rval 
          f_out.write( buf )

     elif int(datacode) == 4:
          if tmiss == 1:
              if re.match( miss, value ):
                  rval = 9.999
              else:
                  rval = float( value )
          else:
              rval = float( value )         
          buf = cyear+','+cmonth+','+cday+','+chour+',%5.3f\n' % rval 
          f_out.write( buf )

fo_in.close()
f_out.close()



