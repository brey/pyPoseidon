# Python Program: Convert Originators Format to SLP64 Format: Hourly Data
#
# P.Caldwell 2014/10/16
#
import os, sys
import re

# Message to user 
print '\n\n           Hourly Format Conversion            \n\n'
print 'Notes:                                                  '
print '1. If not already, in ../dat, make file with format'
print '   with each row having one date and one hourly data value\n                   '
print 'example:                                                '
print '1986,01,01,00, 2533                                     '
print '1986,01,01,01, 2406                                     '
print '1986,01,01,02, 2138                                 \n'
print '-- Date can be yyyy mm dd hh or any combination\n       '
print '-- characters between the dates or values can be anything'
print '  (commas, space, dash, etc.) since they are ignored\n'
print '-- All columns must line up (fixed position), that is, '
print '   yyyy (year) must be 4 digits, ie, 2014                 '
print '   mm dd hh must each be 2 digits, if not (and CSV format)'
print '   use csv_to_fixed_columns.py \n'
print '-- Multiple years in one file OK                     \n'
print '2. If missing data, then two options:                  '
print '   a) leave date-value row out of original data file'
print '   b) use missing data flag                          \n'
print '3. Edit ../din/dtdcnv.din and define column   '
print '   positions of each field, (default is as example above).'
print '   Note, there are 4 files to correspond to '
print '   options 1-4 below, that can be copied to dtdcnv.din.'
print '   These fixed examples use YYYY MM DD HH, change if necessary.'
print '   These steps must be done prior to running convert.py\n'
print '4. Output in millimeters (mm) \n\n'

# Interactive input
print 'Interactive Input, please enter parameters as requested\n'

orgfn = raw_input('Originator filename (in ../dat) : ')

print '\nTime zone of original data, 4-positions, eg, 075W'
print 'or 060E or for GMT, use 000E'
timezone = raw_input('=============> ')
icnt = 0
while icnt < 5:
    if len(timezone) == 4:
       break
    else:
       print 'Bad input, must be 4-positions, like 075W, try again'
       timezone = raw_input('=============> ')
    icnt += 1

print '\nCode for sea level data format and missing data flag, if used'
print '     1: 5-digits in mm, range -9999 to 9998, flag 9999'
print '        eg. -1223 or  3214 (read in fortran F5.0 or I5) '
print '     2: 6-positions in cm, range -999.9 to 999.8, flag 999.9'
print '        eg. -122.3 or   321.4 (read in fortran F6.1) '
print '     3: 7-positions in m, range -99.999 to 99.998, flag 99.999'
print '        eg. -12.823 or   3.214 (read in fortran F7.3) '
print '     4: 5-positions in m, range -.999 to 9.998, flag 9.999'
print '        eg.   2.823 or   3.214 (read in fortran F5.3) '
imo = 0
while imo < 5:
   datacode = raw_input('Enter code number (1, 2, 3, or 4) ==> ')
   mo=re.match( "[0-9]", datacode)
   if mo:
      break
   else:
      print '\nBad input, must be a number from 1 to 4, try again\n'
   imo += 1
icnt = 0
while icnt < 5:
   if int(datacode) == 1:
      break
   elif int(datacode) == 2:
      break
   elif int(datacode) == 3:
      break
   elif int(datacode) == 4:
      break
   else:
      print 'Bad input, must be 1, 2, 3, or 4 try again'
      datacode = raw_input('Enter code number (1, 2, 3, or 4) ==> ')
   icnt += 1

print ' \n'
imo = 0
while imo < 5:
   version = raw_input(
      'Enter file version of SLP64 formatted output file (eg. a) : ')
   mo=re.match( "[a-zA-Z]", version)
   if mo:
       break
   else:
       print '\nBad input, must be letter a-z or A-Z, try again\n'
   imo += 1
print ' \n'

stanum = raw_input('Station number as 3-positions (eg 003): ')
icnt = 0
while icnt < 5:
    if len(stanum) == 3:
       break
    else:
       print 'Bad input, must be 3-positions, like 003, try again'
       stanum = raw_input('=============> ')
    icnt += 1
print ' \n'

# File cleanup if necessary
print '\n\nProgram is checking if temporary files exist from'
print 'earlier runs of convert.py since the embedded Fortran'
print 'programs will abort if they exist'
print 'IGNORE STATEMENTS BELOW, which occur if they do not exist, that is good!\n\n'
os.system( 'ls  temp.dat > tmpfiles.lst' )
os.system( 'ls  tmp_opts.inp >> tmpfiles.lst' )
lines=open('tmpfiles.lst','r').readlines()
for line in lines:
   if re.match('temp.dat', line):
      os.system('rm ' + line)
   elif re.match('tmp_opts.inp', line):
      os.system('rm ' + line)
os.system( 'rm tmpfiles.lst' )
print '\n End Existing Files Test\n\n'

# Put options in temporary file
fo_tm = open( 'tmp_opts.inp', 'w' )

oripath = '../dat/'
fo_tm.write( oripath+orgfn+'\n' )
fo_tm.write( timezone+'\n' )
fo_tm.write( datacode+'\n' )
fo_tm.write( version+stanum+'\n' )
fo_tm.close()

# Run DTDCNV
os.system( 'dtdcnv.exe' )

#File cleanup
os.system( 'ls temp.dat > tmpfiles.lst' )
os.system( 'ls tmp_opts.inp >> tmpfiles.lst' )
lines=open('tmpfiles.lst','r').readlines()
for line in lines:
   if re.match('temp.dat', line):
      os.system('rm ' + line)
   elif re.match('tmp_opts.inp', line):
      os.system('rm ' + line)
os.system( 'rm tmpfiles.lst' )
print '\n\n Output in ../dat\n\n'

