
Files on directory /slp64/util: 'Utilities'

Executable programs 

FILENAME       COMMENT
-------------  -----------------------------------
addval   exe   add a constant value to each hourly data
               if zero reference needs changing 
               (same as coref.exe under QC)
chunit   exe   Change scientific units of data

csv_to_fixed_columns.py  Program to supplement convert.py
                         This and the following program
                         must be run before running convert.py

nos_to_fixed_columns.py  Make NOAA/NOS/COOPS format fixed 
                         columns and change missing data
                         flag from dash to 9.999
                         (note, header and footer must be
                          removed from NOS file before running)

convert  py    Convert data to SLP64 format for hourly data
               *see notes in readme.txt within ../din
               *USE csv_to_fixed_columns.py if original data
                are CSV and columns do not line up
               *more notes also given upon execution of convert.py
dtdcnv   exe   executable used by convert.py

gapcou   exe   List gaps 

fillmonths py  python program to run FILLVM, blocks missing data
fillvm   exe   Create monthly blocks of missing 
               data flags

tsall    exe   shift time zone for multiple years

hsl2csv  exe   SLP64 format to CSV for hourly data
dsl2csv  exe   SLP64 format to CSV for daily data
msl2csv  exe   SLP64 format to CSV for monthly data

