
Files on directory /slp64/util/src: 'Utilities'

Fortran source code 

FILENAME       COMMENT
-------------  -----------------------------------
ADDVAL   FOR   add a constant value to each hourly data
               if zero reference needs changing 
               (same as coref.FOR under QC)

CHUNIT   FOR   Change scientific units of data


DTDCNV   FOR   Convert data to SLP64 format for hourly data
               *put input file in this directory before running
               *delete temporary file temp.dat after running
                (program will not run if this file exists)
               *output placed on ../dat

GAPCOU   FOR   List gaps 

FILLVM   FOR   Create monthly blocks of missing 
               data flags

TSALL    FOR   shift time zone for multiple years

hsl2csv  FOR   SLP64 format to CSV for hourly data
dsl2csv  FOR   SLP64 format to CSV for daily data
msl2csv  FOR   SLP64 format to CSV for monthly data

