# convert NOAA/NOS file so value has fixed number of positions
#
# P.Caldwell 2014/10/17
#
import os, sys
import re

# Message to user 
print '\n\n     Convert NOAA/NOS to fixed-column-positioned file \n\n'

# Interactive input
print 'Interactive Input, please enter parameters as requested\n'

orgfn = raw_input('Originator CSV filename (in ../dat) : ')
print ' \n'

newfn = raw_input('Output filename (into ../dat) : ')
print ' \n'

# Open files
oripath = '../dat/'
fo_in = open( oripath+orgfn, 'r' )
f_out = open( oripath+newfn, 'w' )
#read entire input file into list lines
lines=fo_in.readlines()

# work with one row at a time
for line in lines:
     # change "/", ":", and tab "\t" to a comma
     buf = re.sub( '[/:\t]', ',', line )
     # now that all delimiters are commas, it is easy to separate fields
     year, month, day, hour, mn, pr, dash, value = buf.split(",")
     # the strings need to be converted to integer
     iyr = int(year)
     imn = int(month)
     idy = int(day)
     ihr = int(hour)

     # place integers into strings with fixed-lengths
     # this is done since Python write only works with strings
     cyear = '%4d' % iyr
     cmonth = '%2d' % imn
     cday = '%2d' % idy
     chour = '%2d' % ihr

     # NOS Missing data flag is dash "-" plus a "\n"
     # make it 9.999 as missing flag
     if re.match('[-]', value) and len(value) == 2:
          rval = 9.999
     else:
        rval = float( value )
        
     # write out
     buf = cyear+','+cmonth+','+cday+','+chour+',%5.3f\n' % rval 
     f_out.write( buf )

fo_in.close()
f_out.close()



