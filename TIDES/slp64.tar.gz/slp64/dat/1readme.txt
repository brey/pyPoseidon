Subdirectory /slp64/dat is used to hold DATA files

*note, letters in lower case for filenames
